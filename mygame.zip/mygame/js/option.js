
if (! ("optionProps" in window)) {
	window.optionProps = {};
}
window.optionProps.magnify = true;
	