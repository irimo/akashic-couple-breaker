"use strict";
// TODO: このファイルは将来的には外部から参照するようにする
Object.defineProperty(exports, "__esModule", { value: true });
exports.STORAGE_MAX_NUMBER = exports.STORAGE_MIN_NUMBER = void 0;
/**
 * "number" の最小値。
 */
exports.STORAGE_MIN_NUMBER = -1073741824; // -(2 ** 30)
/**
 * "number" の最大値。
 */
exports.STORAGE_MAX_NUMBER = 1073741823; // (2 ** 30) - 1;
